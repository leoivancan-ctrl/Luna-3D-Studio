package hr.luna.studio;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import java.io.InputStream;
public class MainActivity extends Activity {
 WebView view;
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  view=new WebView(this);
  setContentView(view);
  WebSettings s=view.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  view.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request){
    android.net.Uri uri=request.getUrl();
    if(!"luna.local".equals(uri.getHost())) return super.shouldInterceptRequest(v,request);
    String path=uri.getPath();
    if(path==null || path.equals("/"))path="/index.html";
    if(!path.equals("/index.html") && !path.equals("/luna.glb"))return null;
    try{
     InputStream in=getAssets().open(path.substring(1));
     String mime=path.endsWith(".glb")?"model/gltf-binary":"text/html";
     return new WebResourceResponse(mime,path.endsWith(".glb")?null:"UTF-8",in);
    }catch(Exception e){return null;}
   }
  });
  view.loadUrl("https://luna.local/index.html");
 }
 @Override public void onBackPressed(){if(view.canGoBack())view.goBack();else super.onBackPressed();}
}
