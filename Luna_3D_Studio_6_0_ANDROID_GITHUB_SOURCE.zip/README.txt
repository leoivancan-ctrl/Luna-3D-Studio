LUNA 3D STUDIO 6.0 - ANDROID GITHUB SOURCE

Nadogradnja postojece verzije 5.0. Ugradeni luna.glb ima walk i run animacije te skin (kostur).

NOVO:
- samostalno hodanje po 3D sobi i pauze
- kontrola hodanja, trcanja, zaustavljanja, prilaska i okretanja
- kamera i opcija pracenja Lune
- brzina i spremljene postavke (localStorage)
- jednostavne tekstualne naredbe na hrvatskom
- poboljsani mobilni izgled

OGRANICENJA:
- Ovo nije AI chat niti gotov eksplicitni simulator.
- Nema animacije sjedenja/lezanja niti sustava presvlacenja.
- Three.js se ucitava s CDN-a, zato je potreban internet.
- Model u ZIP-u nije nuzno isti kao zeljeni referentni lik.
- APK nije izgraden/testiran u ovom okruzenju; izgradnja preko GitHub Actions.

GITHUB:
1. Raspakiraj ZIP u korijen repozitorija (ne uploadati ZIP kao jednu datoteku).
2. Commit na main.
3. Actions -> Build Luna 3D Studio APK -> Run workflow.
4. Po zavrsetku preuzmi Luna-3D-Studio-6-APK artifact.

Napomena: Potrebno je provjeriti podrzava li instalirani Android WebView WebGL i ucitavanje s CDN-a.
